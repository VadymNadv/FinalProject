// Елементи DOM
const productGrid = document.getElementById('productGrid');
const searchInput = document.getElementById('searchInput');
const sortSelect = document.getElementById('sortSelect');
const cartModal = document.getElementById('cartModal');
const openCartBtn = document.getElementById('openCartBtn');
const cartCloseBtn = document.getElementById('cart-close');
const cartItemsContainer = document.getElementById('cartItems');
const cartTotal = document.getElementById('cartTotal');

let products = [];
let cart = [];

// Отримати продукти з API
async function fetchProducts() {
    const res = await fetch('https://fakestoreapi.com/products');
    products = await res.json();
    renderProducts(products);
}

function renderProducts(list) {
    productGrid.innerHTML = '';
    list.forEach(product => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
            <img src="${product.image}" alt="${product.title}" />
            <div class="info">
                <h3>${product.title}</h3>
                <p>₴${product.price.toFixed(2)}</p>
                <p>Рейтинг: ${product.rating.rate}/5⭐</p>
                <div class="card-actions">
                    <button class="view-details" data-id="${product.id}">Детальніше</button>
                    <button class="add-to-cart" data-id="${product.id}">Додати в кошик</button>
                </div>
            </div>
        `;
        productGrid.appendChild(card);
    });
    addListeners();
}

function addListeners() {
    document.querySelectorAll('.add-to-cart').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = parseInt(btn.dataset.id);
            const product = products.find(p => p.id === id);
            addToCart(product);
            alert(`"${product.title}" додано в кошик!`);
        });
    });

    document.querySelectorAll('.view-details').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = parseInt(btn.dataset.id);
            openModal(id);
        });
    });
}

function sortProducts(criteria) {
    let sorted = [...products];
    if (criteria === 'price-low') sorted.sort((a, b) => a.price - b.price);
    else if (criteria === 'price-high') sorted.sort((a, b) => b.price - a.price);
    else if (criteria === 'rating') sorted.sort((a, b) => b.rating.rate - a.rating.rate);
    renderProducts(sorted);
}

function filterProducts() {
    const query = searchInput.value.toLowerCase();
    const filtered = products.filter(p => p.title.toLowerCase().includes(query));
    renderProducts(filtered);
}

searchInput.addEventListener('input', filterProducts);
sortSelect.addEventListener('change', e => sortProducts(e.target.value));

function openModal(id) {
    const product = products.find(p => p.id === id);
    const modal = document.getElementById('productModal');
    modal.querySelector('.modal-title').textContent = product.title;
    modal.querySelector('.modal-desc').textContent = product.description;
    modal.querySelector('.modal-price').textContent = `₴${product.price.toFixed(2)}`;
    modal.querySelector('.modal-image').src = product.image;

    modal.style.display = 'flex';

    modal.querySelector('.modal-add').onclick = () => {
        addToCart(product);
        alert(`"${product.title}" додано в кошик!`);
    };
}

document.getElementById('modal-close').addEventListener('click', () => {
    document.getElementById('productModal').style.display = 'none';
});

openCartBtn.addEventListener('click', () => {
    renderCart();
    cartModal.style.display = 'flex';
});

cartCloseBtn.addEventListener('click', () => {
    cartModal.style.display = 'none';
});

function renderCart() {
    cartItemsContainer.innerHTML = '';
    let total = 0;

    cart.forEach(item => {
        total += item.price * item.quantity;

        const cartItem = document.createElement('div');
        cartItem.classList.add('cart-item');
        cartItem.innerHTML = `
            <img src="${item.image}" alt="${item.title}" class="cart-thumb" />
            <div class="cart-details">
                <strong>${item.title}</strong><br>
                Ціна: ₴${item.price.toFixed(2)} <br>
                Кількість:
                <button class="qty-btn" data-id="${item.id}" data-action="decrease">−</button>
                ${item.quantity}
                <button class="qty-btn" data-id="${item.id}" data-action="increase">+</button>
                <button class="remove-btn" data-id="${item.id}">🗑</button>
            </div>
        `;

        cartItemsContainer.appendChild(cartItem);
    });

    cartTotal.textContent = `Загальна сума: ₴${total.toFixed(2)}`;

    document.querySelectorAll('.qty-btn').forEach(btn => {
        const id = parseInt(btn.dataset.id);
        const action = btn.dataset.action;

        btn.onclick = () => {
            const item = cart.find(p => p.id === id);
            if (action === 'increase') item.quantity++;
            if (action === 'decrease') item.quantity = Math.max(1, item.quantity - 1);
            renderCart();
        };
    });

    document.querySelectorAll('.remove-btn').forEach(btn => {
        const id = parseInt(btn.dataset.id);
        btn.onclick = () => {
            cart = cart.filter(p => p.id !== id);
            renderCart();
        };
    });
}

document.getElementById('checkoutBtn').addEventListener('click', () => {
    localStorage.setItem('order', JSON.stringify(cart));
    window.location.href = 'order.html';
});


function addToCart(product) {
    const existing = cart.find(p => p.id === product.id);
    if (existing) {
        existing.quantity++;
    } else {
        cart.push({ ...product, quantity: 1 });
    }
    renderCart();
}

fetchProducts();
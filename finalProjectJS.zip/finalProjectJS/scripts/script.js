// === ІНІЦІАЛІЗАЦІЯ ЕЛЕМЕНТІВ ===
const productGrid = document.getElementById('productGrid');
const carousel = document.querySelector('.carousel');
const cards = document.querySelectorAll('.card');

// === РЕНДЕРИНГ ПРОДУКТІВ ===
async function fetchProducts() {
    const res = await fetch('https://fakestoreapi.com/products');
    const data = await res.json();
    renderProducts(data);
}
function renderProducts(products) {
    productGrid.innerHTML = '';
    products.forEach(product => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
            <img src="${product.image}" alt="${product.title}" />
            <div class="info">
                <h3 style="font-size: 1rem; margin-bottom: 8px;">${product.title}</h3>
                <p style="color: #4b5563; margin-bottom: 8px;">₴${product.price.toFixed(2)}</p>
                <button>Додати в кошик</button>
            </div>
        `;
        productGrid.appendChild(card);
    });
}
fetchProducts();

// === ІНТЕРАКТИВНІ КАРТКИ (видимість при скролі) ===
const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, {
    threshold: 0.3
});
cards.forEach(card => observer.observe(card));

// === ЗМІНА ЗОБРАЖЕННЯ (для елементів з класом .card) ===
function changeImage(index) {
    const cards = document.querySelectorAll('.card');
    const images = document.querySelectorAll('.image-wrapper img');

    cards.forEach((card, i) => {
        card.classList.toggle('active', i === index);
    });

    images.forEach((img, i) => {
        img.classList.toggle('active', i === index);
    });
}

// === АКОРДЕОН ДЛЯ FAQ ===
function toggleAccordion(index) {
    const items = document.querySelectorAll('.faq-item');
    items.forEach((item, i) => {
        if (i === index) {
            item.classList.toggle('active');
        } else {
            item.classList.remove('active');
        }
    });
}

// === КАРУСЕЛЬ ЗОБРАЖЕНЬ ===
let currentImageIndex = 0;

async function fetchImages() {
    const res = await fetch('https://fakestoreapi.com/products');
    const data = await res.json();
    renderCarouselImages(data);
}
function renderCarouselImages(products) {
    carousel.innerHTML = '';
    const selectedProducts = products.slice(0, 5);

    selectedProducts.forEach(product => {
        const imgElement = document.createElement('img');
        imgElement.src = product.image;
        imgElement.alt = product.title;
        imgElement.classList.add('carousel-image');
        carousel.appendChild(imgElement);
    });

    updateActiveImage();
}
function updateActiveImage() {
    const images = document.querySelectorAll('.carousel-image');
    images.forEach((img, index) => {
        img.classList.toggle('active', index === currentImageIndex);
    });
}
function changeCarouselImage(direction) {
    const images = document.querySelectorAll('.carousel-image');
    currentImageIndex += direction;

    if (currentImageIndex < 0) {
        currentImageIndex = images.length - 1;
    } else if (currentImageIndex >= images.length) {
        currentImageIndex = 0;
    }

    updateActiveImage();
}
fetchImages();

// === КНОПКИ КАРУСЕЛІ ===
document.querySelector('.prev').addEventListener('click', () => changeCarouselImage(-1));
document.querySelector('.next').addEventListener('click', () => changeCarouselImage(1));

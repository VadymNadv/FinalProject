const orderList = document.getElementById('orderList');
const orderTotal = document.getElementById('orderTotal');
const cart = JSON.parse(localStorage.getItem('order')) || [];

let total = 0;

cart.forEach(item => {
    total += item.price * item.quantity;

    const itemDiv = document.createElement('div');
    itemDiv.className = 'order-item';
    itemDiv.innerHTML = `
            <img src="${item.image}" alt="${item.title}">
            <div>
                <strong>${item.title}</strong><br>
                Ціна: ₴${item.price.toFixed(2)}<br>
                Кількість: ${item.quantity}
            </div>
        `;
    orderList.appendChild(itemDiv);
});

orderTotal.textContent = `Загальна сума: ₴${total.toFixed(2)}`;

function confirmOrder() {
    const name = document.getElementById('name').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const address = document.getElementById('address').value.trim();

    if (!name || !phone || !address) {
        alert('Будь ласка, заповніть всі поля для оформлення замовлення.');
        return;
    }

    alert(`Дякуємо за замовлення, ${name}! Ми зв'яжемося з вами найближчим часом.`);
    localStorage.removeItem('order');
    window.location.href = 'index.html';
}